interface Window {
  webkitSpeechRecognition: any;
  SpeechRecognition: any;
}